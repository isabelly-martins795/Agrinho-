// Estados do jogo
let gameState = 'menu';
let selectedPlayer = '';
let coins = 0;
let plantedCrops = [];
let harvestedCrops = 0;
let showCar = false;
let showInstructions = false;
let gameCompleted = false;
let fireworks = [];
let player1Completed = false;
let player2Completed = false;

// Botões
let buttons = {};

function setup() {
  createCanvas(800, 600);
  
  // Inicializar botões do menu
  buttons.startGame = {x: 400, y: 200, w: 200, h: 50, text: 'INICIAR JOGO'};
  buttons.player1 = {x: 400, y: 270, w: 200, h: 50, text: 'PLAYER 1'};
  buttons.player2 = {x: 400, y: 340, w: 200, h: 50, text: 'PLAYER 2'};
  buttons.instructions = {x: 400, y: 410, w: 200, h: 50, text: 'INSTRUÇÕES'};
  buttons.back = {x: 400, y: 500, w: 150, h: 40, text: 'VOLTAR'};
  buttons.car = {x: 650, y: 400, w: 120, h: 80, text: 'VIAJAR'};
}

function draw() {
  updateCrops();
  
  if (gameState === 'menu') {
    drawMenu();
  } else if (gameState === 'instructions') {
    drawInstructions();
  } else if (gameState === 'player1') {
    drawFarmScene();
  } else if (gameState === 'player2') {
    drawCityScene();
  } else if (gameState === 'victory') {
    drawVictoryScene();
  }
}

function drawMenu() {
  // Fundo gradient
  for (let i = 0; i <= height; i++) {
    let inter = map(i, 0, height, 0, 1);
    let c = lerpColor(color(135, 206, 235), color(152, 251, 152), inter);
    stroke(c);
    line(0, i, width, i);
  }
  
  // Título
  fill(60, 90, 60);
  textAlign(CENTER, CENTER);
  textSize(48);
  textStyle(BOLD);
  text('CAMPO & CIDADE', width/2, 100);
  
  // Subtítulo
  fill(80, 120, 80);
  textSize(18);
  text('Conecte o campo e a cidade!', width/2, 140);
  
  // Moedas no menu (se houver)
  if (coins > 0) {
    fill(255, 215, 0);
    textSize(24);
    text('💰 Moedas: ' + coins, width/2, 160);
  }
  
  // Botões
  drawButton(buttons.startGame, gameCompleted);
  drawButton(buttons.player1, true);
  drawButton(buttons.player2, true);
  drawButton(buttons.instructions, true);
  
  // Mostrar personagens se ambos completaram
  if (player1Completed && player2Completed) {
    drawCharacters();
    updateFireworks();
  }
}

function drawInstructions() {
  background(240, 248, 255);
  
  // Título
  fill(60, 90, 60);
  textAlign(CENTER, CENTER);
  textSize(36);
  text('INSTRUÇÕES', width/2, 80);
  
  // Instruções principais
  fill(80, 120, 80);
  textSize(20);
  text('Escolha seu player e seu trabalho e conecte', width/2, 200);
  text('o campo e a cidade, assim você recebe moedas!', width/2, 230);
  
  // Detalhes dos players
  textSize(16);
  fill(34, 139, 34);
  text('🌾 PLAYER 1: Trabalhe no campo, plante e colha', width/2, 300);
  fill(70, 130, 180);
  text('🏢 PLAYER 2: Trabalhe na cidade, compre grãos', width/2, 330);
  fill(255, 165, 0);
  text('💰 Complete as tarefas para ganhar moedas!', width/2, 360);
  
  drawButton(buttons.back, true);
}

function drawFarmScene() {
  // Céu
  for (let i = 0; i <= height * 0.6; i++) {
    let inter = map(i, 0, height * 0.6, 0, 1);
    let c = lerpColor(color(135, 206, 235), color(200, 230, 255), inter);
    stroke(c);
    line(0, i, width, i);
  }
  
  // Campo
  fill(34, 139, 34);
  noStroke();
  rect(0, height * 0.6, width, height * 0.4);
  
  // Sol
  fill(255, 255, 0);
  ellipse(700, 100, 80, 80);
  
  // Raios do sol
  stroke(255, 255, 0);
  strokeWeight(3);
  for (let i = 0; i < 8; i++) {
    let angle = (TWO_PI / 8) * i;
    let x1 = 700 + cos(angle) * 50;
    let y1 = 100 + sin(angle) * 50;
    let x2 = 700 + cos(angle) * 70;
    let y2 = 100 + sin(angle) * 70;
    line(x1, y1, x2, y2);
  }
  
  // Nuvens
  drawCloud(150, 120);
  drawCloud(500, 100);
  
  // UI do jogo
  noStroke();
  fill(255, 255, 255, 220);
  rect(10, 10, 200, 90, 10);
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  text('🌾 FAZENDEIRO', 20, 25);
  text('Colheitas: ' + harvestedCrops + '/5', 20, 45);
  text('💰 Moedas: ' + coins, 20, 65);
  
  // Instruções
  textAlign(CENTER, CENTER);
  textSize(18);
  fill(255, 255, 255, 200);
  rect(width/2 - 150, height - 50, 300, 30, 15);
  fill(60, 90, 60);
  text('Clique no campo para plantar e colher!', width/2, height - 35);
  
  // Desenhar plantações
  for (let crop of plantedCrops) {
    drawCrop(crop.x, crop.y, crop.stage);
  }
  
  // Mostrar carro quando terminar
  if (showCar) {
    drawCar();
    drawButton(buttons.car, true);
  }
}

function drawCityScene() {
  // Céu urbano
  for (let i = 0; i <= height * 0.3; i++) {
    let inter = map(i, 0, height * 0.3, 0, 1);
    let c = lerpColor(color(100, 149, 237), color(176, 196, 222), inter);
    stroke(c);
    line(0, i, width, i);
  }
  
  // Chão da cidade
  noStroke();
  fill(70, 70, 70);
  rect(0, height * 0.3, width, height * 0.7);
  
  // Prédios de fundo
  drawBuildings();
  
  // Escritório principal
  fill(200, 200, 255);
  rect(width/2 - 150, height/2 - 100, 300, 200, 10);
  fill(100, 100, 150);
  rect(width/2 - 140, height/2 - 90, 280, 30, 5);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(16);
  text('ESCRITÓRIO DE COMPRAS', width/2, height/2 - 75);
  
  // UI do jogo
  fill(255, 255, 255, 220);
  rect(10, 10, 200, 90, 10);
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  text('🏢 COMPRADOR', 20, 25);
  text('Negócios: ' + (player2Completed ? '5/5' : '0/5'), 20, 45);
  text('💰 Moedas: ' + coins, 20, 65);
  
  // Mesa de trabalho
  fill(139, 69, 19);
  rect(width/2 - 100, height/2, 200, 80, 5);
  fill(255);
  rect(width/2 - 90, height/2 + 10, 180, 60, 5);
  
  // Papéis na mesa
  fill(240);
  rect(width/2 - 70, height/2 + 20, 50, 40);
  rect(width/2 + 10, height/2 + 25, 40, 30);
  
  // Instruções
  textAlign(CENTER, CENTER);
  textSize(18);
  fill(255, 255, 255, 200);
  rect(width/2 - 150, height - 50, 300, 30, 15);
  fill(60, 90, 60);
  text('Clique na mesa para fazer negócios!', width/2, height - 35);
}

function drawVictoryScene() {
  // Fundo festivo
  for (let i = 0; i <= height; i++) {
    let inter = map(i, 0, height, 0, 1);
    let c = lerpColor(color(255, 215, 0), color(255, 69, 0), inter);
    stroke(c);
    line(0, i, width, i);
  }
  
  // Título de vitória
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(48);
  textStyle(BOLD);
  text('PARABÉNS!', width/2, 150);
  
  textSize(24);
  textStyle(NORMAL);
  text('Conexão entre Campo e Cidade estabelecida!', width/2, 200);
  text('💰 Total de moedas: ' + coins, width/2, 250);
  
  // Personagens comemorando
  drawCharacters();
  
  // Fogos de artifício
  updateFireworks();
  
  // Botão voltar
  drawButton(buttons.back, true);
}

function drawButton(btn, enabled) {
  // Sombra do botão
  fill(0, 0, 0, 50);
  rect(btn.x - btn.w/2 + 3, btn.y - btn.h/2 + 3, btn.w, btn.h, 10);
  
  // Botão
  if (enabled) {
    fill(100, 200, 100);
    if (isMouseOverButton(btn)) {
      fill(120, 220, 120);
    }
  } else {
    fill(150, 150, 150);
  }
  
  stroke(60, 120, 60);
  strokeWeight(2);
  rect(btn.x - btn.w/2, btn.y - btn.h/2, btn.w, btn.h, 10);
  
  fill(enabled ? 255 : 200);
  noStroke();
  textAlign(CENTER, CENTER);
  textSize(16);
  textStyle(BOLD);
  text(btn.text, btn.x, btn.y);
}

function drawCloud(x, y) {
  fill(255, 255, 255, 200);
  noStroke();
  ellipse(x, y, 60, 40);
  ellipse(x + 20, y, 80, 50);
  ellipse(x + 40, y, 60, 40);
}

function drawCrop(x, y, stage) {
  if (stage === 'planted') {
    // Terra revolvida
    fill(139, 69, 19);
    ellipse(x, y, 20, 15);
    // Broto pequeno
    fill(0, 100, 0);
    rect(x - 2, y - 8, 4, 6);
  } else if (stage === 'grown') {
    // Planta crescida
    fill(255, 215, 0);
    ellipse(x, y - 15, 25, 20);
    fill(0, 150, 0);
    rect(x - 3, y - 5, 6, 20);
    // Folhas
    fill(0, 200, 0);
    ellipse(x - 10, y - 10, 15, 8);
    ellipse(x + 10, y - 10, 15, 8);
  }
}

function drawCar() {
  // Sombra do carro
  fill(0, 0, 0, 100);
  ellipse(650, 480, 120, 20);
  
  // Corpo do carro
  fill(255, 0, 0);
  rect(570, 420, 100, 40, 10);
  
  // Janelas
  fill(135, 206, 235);
  rect(580, 425, 80, 20, 5);
  
  // Rodas
  fill(0);
  ellipse(590, 470, 20, 20);
  ellipse(650, 470, 20, 20);
  
  // Detalhes das rodas
  fill(100);
  ellipse(590, 470, 10, 10);
  ellipse(650, 470, 10, 10);
}

function drawBuildings() {
  noStroke();
  // Vários prédios
  fill(100, 100, 100);
  rect(50, height * 0.3, 80, height * 0.5);
  rect(150, height * 0.2, 60, height * 0.6);
  rect(230, height * 0.35, 90, height * 0.45);
  rect(500, height * 0.25, 70, height * 0.55);
  rect(590, height * 0.4, 85, height * 0.4);
  
  // Janelas iluminadas
  fill(255, 255, 0);
  for (let building = 0; building < 5; building++) {
    let buildingX = [60, 160, 240, 510, 600][building];
    let buildingY = [height * 0.35, height * 0.25, height * 0.4, height * 0.3, height * 0.45][building];
    let buildingW = [60, 40, 70, 50, 65][building];
    
    for (let i = 0; i < 8; i++) {
      for (let j = 0; j < 4; j++) {
        if (random() > 0.4) {
          rect(buildingX + j * 12, buildingY + i * 20, 8, 8);
        }
      }
    }
  }
}

function drawCharacters() {
  // Fazendeiro
  fill(255, 220, 177);
  ellipse(300, 350, 60, 60);
  fill(0, 100, 0);
  rect(285, 380, 30, 60);
  fill(139, 69, 19);
  rect(280, 440, 40, 20);
  
  // Chapéu do fazendeiro
  fill(210, 180, 140);
  ellipse(300, 330, 70, 20);
  rect(285, 320, 30, 20);
  
  // Empresário
  fill(255, 220, 177);
  ellipse(500, 350, 60, 60);
  fill(0, 0, 139);
  rect(485, 380, 30, 60);
  fill(0);
  rect(480, 440, 40, 20);
  
  // Gravata do empresário
  fill(200, 0, 0);
  triangle(500, 380, 490, 400, 510, 400);
  
  // Emojis de felicidade
  textSize(30);
  text('😊', 300, 320);
  text('🤝', 400, 300);
  text('😊', 500, 320);
  
  // Movimento sutil
  let bounce = sin(frameCount * 0.1) * 2;
  translate(0, bounce);
  fill(255, 0, 0);
  textSize(20);
  text('❤️', 350, 280);
  text('❤️', 450, 280);
  translate(0, -bounce);
}

function updateFireworks() {
  // Criar novos fogos
  if (frameCount % 30 === 0) {
    fireworks.push({
      x: random(width),
      y: random(100, 300),
      particles: []
    });
  }
  
  // Atualizar fogos existentes
  for (let i = fireworks.length - 1; i >= 0; i--) {
    let fw = fireworks[i];
    
    if (fw.particles.length === 0) {
      // Explodir
      for (let j = 0; j < 15; j++) {
        fw.particles.push({
          x: fw.x,
          y: fw.y,
          vx: random(-4, 4),
          vy: random(-4, 4),
          life: 60,
          color: color(random(255), random(255), random(255))
        });
      }
    }
    
    // Desenhar partículas
    noStroke();
    for (let j = fw.particles.length - 1; j >= 0; j--) {
      let p = fw.particles[j];
      fill(red(p.color), green(p.color), blue(p.color), p.life * 4);
      ellipse(p.x, p.y, 6, 6);
      
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.1; // Gravidade
      p.life--;
      
      if (p.life <= 0) {
        fw.particles.splice(j, 1);
      }
    }
    
    if (fw.particles.length === 0) {
      fireworks.splice(i, 1);
    }
  }
}

function mousePressed() {
  if (gameState === 'menu') {
    if (isButtonClicked(buttons.startGame) && gameCompleted) {
      // Reset do jogo
      resetGame();
      gameState = 'menu';
    } else if (isButtonClicked(buttons.player1)) {
      selectedPlayer = 'player1';
      gameState = 'player1';
      resetPlayerData();
    } else if (isButtonClicked(buttons.player2)) {
      selectedPlayer = 'player2';
      gameState = 'player2';
      resetPlayerData();
    } else if (isButtonClicked(buttons.instructions)) {
      gameState = 'instructions';
    }
  } else if (gameState === 'instructions') {
    if (isButtonClicked(buttons.back)) {
      gameState = 'menu';
    }
  } else if (gameState === 'player1') {
    if (showCar && isButtonClicked(buttons.car)) {
      // Ir para a cidade vender
      coins += harvestedCrops * 10;
      player1Completed = true;
      checkGameCompletion();
      gameState = 'menu';
    } else if (mouseY > height * 0.6 && !showCar) {
      // Plantar/colher no campo
      plantCrop(mouseX, mouseY);
    }
  } else if (gameState === 'player2') {
    if (mouseX > width/2 - 100 && mouseX < width/2 + 100 &&
        mouseY > height/2 && mouseY < height/2 + 80) {
      // Fazer negócio na mesa
      coins += 50;
      player2Completed = true;
      checkGameCompletion();
      gameState = 'menu';
    }
  } else if (gameState === 'victory') {
    if (isButtonClicked(buttons.back)) {
      gameState = 'menu';
    }
  }
}

function isButtonClicked(btn) {
  return mouseX > btn.x - btn.w/2 && mouseX < btn.x + btn.w/2 &&
         mouseY > btn.y - btn.h/2 && mouseY < btn.y + btn.h/2;
}

function isMouseOverButton(btn) {
  return mouseX > btn.x - btn.w/2 && mouseX < btn.x + btn.w/2 &&
         mouseY > btn.y - btn.h/2 && mouseY < btn.y + btn.h/2;
}

function plantCrop(x, y) {
  // Verificar se já existe uma plantação nesse local
  for (let i = 0; i < plantedCrops.length; i++) {
    let crop = plantedCrops[i];
    if (dist(x, y, crop.x, crop.y) < 30) {
      if (crop.stage === 'grown') {
        // Colher
        harvestedCrops++;
        plantedCrops.splice(i, 1);
        
        if (harvestedCrops >= 5) {
          showCar = true;
        }
      }
      return;
    }
  }
  
  // Plantar nova cultura (máximo 10 plantas)
  if (plantedCrops.length < 10) {
    plantedCrops.push({
      x: x,
      y: y,
      stage: 'planted',
      growTime: frameCount + 120 // 2 segundos para crescer
    });
  }
}

function resetPlayerData() {
  plantedCrops = [];
  harvestedCrops = 0;
  showCar = false;
}

function resetGame() {
  coins = 0;
  plantedCrops = [];
  harvestedCrops = 0;
  showCar = false;
  gameCompleted = false;
  player1Completed = false;
  player2Completed = false;
  fireworks = [];
}

function checkGameCompletion() {
  if (player1Completed && player2Completed) {
    gameCompleted = true;
    gameState = 'victory';
  }
}

function updateCrops() {
  for (let crop of plantedCrops) {
    if (crop.stage === 'planted' && frameCount > crop.growTime) {
      crop.stage = 'grown';
    }
  }
}